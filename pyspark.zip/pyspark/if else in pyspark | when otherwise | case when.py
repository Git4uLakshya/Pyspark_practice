# Databricks notebook source
# MAGIC %md
# MAGIC This sheet will cover
# MAGIC * case when in spark sql 
# MAGIC * when otherwise in pyspark 
# MAGIC * How to deal with null value
# MAGIC * case when | when otherwise with multiple AND,OR conditions

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

emp_data = [
(1,'manish',26,20000,'india','IT'),
(2,'rahul',None,40000,'germany','engineering'),
(3,'pawan',12,60000,'india','sales'),
(4,'roshini',44,None,'uk','engineering'),
(5,'raushan',35,70000,'india','sales'),
(6,None,29,200000,'uk','IT'),
(7,'adam',37,65000,'us','IT'),
(8,'chris',16,40000,'us','sales'),
(None,None,None,None,None,None),
(7,'adam',37,65000,'us','IT')
]
emp_schema=['id','name','age','salary','country','dept']
emp_df=spark.createDataFrame(data=emp_data,schema=emp_schema)
emp_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC When otherwise

# COMMAND ----------

#As discussed earlier, If you want or manipulate a existing column or create a new column *with column* will help you in that. If already a column is present, then it will override that
#
emp_df.withColumn('age',when (col('age').isNull(),'19')
                        .otherwise(col('age')))\
    .withColumn('adult',when(col('age')>18,'Adult')
                        .otherwise ('not_adult')).show()

# COMMAND ----------

 emp_df.withColumn('age_wise',when(col('age')<18,'Minor')
                            .when((col('age')>18) & (col('age')<30),'Mid')
                            .otherwise('Major'))\
                            .show()

# COMMAND ----------

# MAGIC %md
# MAGIC Case When

# COMMAND ----------

emp_df.createOrReplaceTempView('emp_table')
spark.sql(
    """
    select *, case when age < 18 then 'Minor'
                    when age>18 and age<30 then 'Mid'
                    when age>30 then 'Major'
                    else 'No value'
                    end as age_wise
    from emp_table
    """
).show()

# COMMAND ----------

